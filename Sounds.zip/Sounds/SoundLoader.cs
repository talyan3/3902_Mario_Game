using Microsoft.Xna.Framework;

namespace MonogameTest.Sounds
{
    public static class SoundLoader
    {
        public static void LoadAllSounds(Game game, SoundManager soundManager)
        {
            // === Background music ===
            soundManager.LoadSong(game, "mainTheme", "Audio/01-main-theme-overworld");
            soundManager.LoadSong(game, "underworld", "Audio/02-underworld");
            soundManager.LoadSong(game, "starman", "Audio/05-starman");
            soundManager.LoadSong(game, "levelComplete", "Audio/06-level-complete");
            soundManager.LoadSong(game, "youreDead", "Audio/08-you-re-dead");
            soundManager.LoadSong(game, "gameOver", "Audio/09-game-over");
            soundManager.LoadSong(game, "gameOver2", "Audio/10-game-over-2");
            soundManager.LoadSong(game, "intoTheTunnel", "Audio/11-into-the-tunnel");
            soundManager.LoadSong(game, "hurry", "Audio/13-hurry");
            soundManager.LoadSong(game, "hurryUnderground", "Audio/14-hurry-underground-");
            soundManager.LoadSong(game, "hurryStarman", "Audio/17-hurry-starman-");
            soundManager.LoadSong(game, "hurryOverworld", "Audio/18-hurry-overworld-");

            // === Sound effects ===
            soundManager.LoadEffect(game, "bump", "Audio/smb_bump");
            soundManager.LoadEffect(game, "coin", "Audio/smb_coin");
            soundManager.LoadEffect(game, "breakBlock", "Audio/smb_breakblock");
            soundManager.LoadEffect(game, "flagpole", "Audio/smb_flagpole");
            soundManager.LoadEffect(game, "jumpSmall", "Audio/smb_jumpsmall");
            soundManager.LoadEffect(game, "jumpSuper", "Audio/smb_jump-super");
            soundManager.LoadEffect(game, "kick", "Audio/smb_kick");
            soundManager.LoadEffect(game, "stomp", "Audio/smb_stomp");
            soundManager.LoadEffect(game, "powerUp", "Audio/smb_powerup");
            soundManager.LoadEffect(game, "powerUpAppears", "Audio/smb_powerup_appears");
            soundManager.LoadEffect(game, "fireball", "Audio/smb_fireball");
            soundManager.LoadEffect(game, "pause", "Audio/smb_pause");
            soundManager.LoadEffect(game, "warning", "Audio/smb_warning");
            soundManager.LoadEffect(game, "oneUp", "Audio/smb_1-up");
        }
    }
}
