namespace MonogameTest;

public class MarioManager
{
    public ISprite ActiveSprite { get; set; }
    public MarioManager()
    {
            
    }
}