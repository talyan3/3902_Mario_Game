using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MonogameTest;

public class TextSprite : ISprite
{
    public void Draw(SpriteBatch spriteBatch, Vector2 position)
    {
        
    }

    public void Update(GameTime gameTime)
    {
        
    }
}