namespace MonogameTest;

public interface IController
{
    
}