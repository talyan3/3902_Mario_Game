﻿using var game = new MonogameTest.Game1();
game.Run();
