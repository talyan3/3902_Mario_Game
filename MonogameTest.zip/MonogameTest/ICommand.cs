using System.Runtime.CompilerServices;
using Microsoft.Xna.Framework;

namespace MonogameTest;

public interface ICommand
{
    public void Execute();
}